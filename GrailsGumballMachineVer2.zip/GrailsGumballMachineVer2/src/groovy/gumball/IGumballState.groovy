package gumball

interface IGumballState {
	def insertCoin()
	def crankHandle()
}
