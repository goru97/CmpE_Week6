jquery {
    sources = 'jquery' // Holds the value where to store jQuery-js files /web-app/js/
    version = org.codehaus.groovy.grails.plugins.jquery.JQueryConfig.SHIPPED_VERSION // The jQuery version in use
}
