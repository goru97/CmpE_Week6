package grailsgumballmachinever1

class GumballController {

    def scaffold = Gumball

}
