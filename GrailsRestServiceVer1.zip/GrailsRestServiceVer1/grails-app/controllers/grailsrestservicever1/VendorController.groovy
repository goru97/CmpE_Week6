package grailsrestservicever1

class VendorController {

	static scaffold = true

}
