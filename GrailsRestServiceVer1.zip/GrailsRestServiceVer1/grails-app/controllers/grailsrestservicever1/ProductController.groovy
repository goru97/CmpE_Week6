package grailsrestservicever1

class ProductController {

	static scaffold = true

}
